# Adminty (Unofficial) Admin Dashboard Template
**Adminty** is a responsive Bootstrap 4.1 admin template. It provides you with a collection of ready to use code snippets and utilities, custom pages, loads of charts, 4 different dashboard variations, a collection of applications and some useful widgets. Preview of this awesome admin template available here: https://colorlib.com//polygon/adminty/default/index.html
### Authors
[Colorlib](https://colorlib.com)

### Demo Site: [[Here]](https://colorlib.com//polygon/adminty/default/index.html)

### More info
- [Bootstrap dashboards](https://colorlib.com/wp/free-bootstrap-admin-dashboard-templates/)
- [Angular dashboards](https://colorlib.com/wp/angularjs-admin-templates/)
- [Free Admin Dashboards](https://colorlib.com/wp/free-html5-admin-dashboard-templates/)
- [Website Templates](https://colorlib.com/wp/templates/)
- [Free WordPress Themes](https://colorlib.com/wp/free-wordpress-themes/)

### License
Always need to state that Colorlib is the original author of this template.
